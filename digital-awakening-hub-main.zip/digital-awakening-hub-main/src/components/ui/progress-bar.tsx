import React from 'react';

interface ProgressBarProps {
  label: string;
  value: string;
  className?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ label, value, className = "" }) => {
  return (
    <div className={`bg-card/80 backdrop-blur-sm rounded-lg p-4 ${className}`}>
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-semibold text-primary">{label}</span>
        <span className="text-sm font-bold text-accent">{value}</span>
      </div>
      <div className="w-full bg-muted rounded-full h-3">
        <div className="bg-gradient-primary h-3 rounded-full w-3/4 animate-pulse"></div>
      </div>
    </div>
  );
};