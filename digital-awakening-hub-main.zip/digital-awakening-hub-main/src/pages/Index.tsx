import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ProgressBar } from "@/components/ui/progress-bar";
import { CheckCircle, Clock, MapPin, Users, Star, Shield } from "lucide-react";
import heroImage from "@/assets/professional-hero.jpg";
import gabrieleImage from "@/assets/gabriele-campora.jpg";
import thinkingWoman from "@/assets/woman-thinking.jpg";

const Index = () => {
  const scrollToInvestment = () => {
    const element = document.getElementById('investment');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-workshop-gray/90 via-workshop-gray/80 to-primary/40"></div>
        </div>
        
        <div className="container relative z-10 px-6 py-20">
          {/* Date Badge */}
          <div className="text-center mb-8">
            <Badge variant="secondary" className="text-lg px-6 py-2 bg-card/90 backdrop-blur-sm">
              27/09 | PRESENCIAL EM SÃO PAULO
            </Badge>
          </div>

          {/* Logo */}
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-4">
              WORKSHOP
            </h1>
            <h2 className="text-4xl md:text-6xl font-bold text-primary-foreground">
              O DESPERTAR DIGITAL
            </h2>
          </div>

          {/* Main Title */}
          <div className="max-w-4xl mx-auto text-center mb-8">
            <h3 className="text-2xl md:text-3xl font-semibold text-primary-foreground leading-relaxed">
              Chegou a hora de despertar o seu potencial digital e{" "}
              <span className="font-bold text-workshop-gray">viver do que você ama</span>{" "}
              com propósito, estratégia e autenticidade.
            </h3>
          </div>

          {/* Support Paragraph */}
          <div className="max-w-4xl mx-auto text-center mb-12">
            <p className="text-lg text-primary-foreground/90 leading-relaxed">
              Se você está <strong>cansada de se sentir perdida no marketing digital</strong> e sabe que pode alcançar mais, 
              este é o seu chamado para virar o jogo. Em um dia de imersão transformadora, você vai descobrir como{" "}
              <strong>despertar todo o seu potencial</strong> e se tornar protagonista no mundo online.
            </p>
          </div>

          {/* CTA Button */}
          <div className="text-center mb-12">
            <Button 
              onClick={scrollToInvestment}
              size="lg" 
              className="text-xl px-12 py-6 bg-workshop-dark-purple hover:bg-workshop-dark-purple/90 text-workshop-white font-bold rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              Garantir minha vaga
            </Button>
          </div>

          {/* Progress Bar */}
          <div className="max-w-md mx-auto">
            <ProgressBar label="PRIMEIRO LOTE" value="VAGAS LIMITADAS" />
          </div>
        </div>
      </section>

      {/* Why Participate Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-6">
          <div className="text-center mb-16">
            <h2 className="text-lg font-bold text-primary tracking-wider mb-4">POR QUE PARTICIPAR?</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-foreground mb-8">
              No workshop <span className="text-primary">O Despertar Digital</span>, você vai aprender a:
            </h3>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto mb-12">
            <Card className="border-primary/20 hover:border-primary/40 transition-colors">
              <CardContent className="p-8">
                <div className="flex items-start space-x-4">
                  <CheckCircle className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="text-xl font-bold text-foreground mb-2">
                      Posicionar-se com confiança
                    </h4>
                    <p className="text-muted-foreground">
                      e se tornar referência no mercado.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-primary/20 hover:border-primary/40 transition-colors">
              <CardContent className="p-8">
                <div className="flex items-start space-x-4">
                  <Star className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="text-xl font-bold text-foreground mb-2">
                      Criar conteúdo de valor
                    </h4>
                    <p className="text-muted-foreground">
                      que gera conexão genuína with seu público.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-primary/20 hover:border-primary/40 transition-colors">
              <CardContent className="p-8">
                <div className="flex items-start space-x-4">
                  <Users className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="text-xl font-bold text-foreground mb-2">
                      Construir uma base de clientes fiéis
                    </h4>
                    <p className="text-muted-foreground">
                      usando estratégias práticas e comprovadas.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-primary/20 hover:border-primary/40 transition-colors">
              <CardContent className="p-8">
                <div className="flex items-start space-x-4">
                  <CheckCircle className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="text-xl font-bold text-foreground mb-2">
                      Usar IA e tráfego pago
                    </h4>
                    <p className="text-muted-foreground">
                      para <strong>acelerar o crescimento</strong> do seu negócio.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center max-w-4xl mx-auto">
            <p className="text-lg text-muted-foreground">
              Tudo isso em um ambiente acolhedor, ao lado de outras mulheres determinadas a crescer e fazer acontecer. 
              Chega de adiar seus sonhos – <strong className="text-primary">é hora de agir e evoluir!</strong>
            </p>
          </div>
        </div>
      </section>

      {/* About Mentor Section */}
      <section className="py-20">
        <div className="container px-6">
          <div className="text-center mb-16">
            <h2 className="text-lg font-bold text-primary tracking-wider mb-4">SOBRE A MENTORA</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto items-center">
            <div className="text-center md:text-left">
              <img 
                src={gabrieleImage}
                alt="Gabriele Campora"
                className="w-80 h-80 object-cover rounded-full mx-auto md:mx-0 shadow-2xl"
              />
            </div>

            <div>
              <h3 className="text-4xl font-bold text-primary mb-6">Gabriele Campora</h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Gabriele Campora é coach de vida e negócios, mentora de mulheres e especialista em posicionamento digital. 
                Com 10 anos de experiência corporativa e 12 anos empreendendo, ela{" "}
                <strong>viveu na pele os desafios</strong> do empreendedorismo e ajudou inúmeras mulheres a crescerem 
                com autenticidade, clareza e consistência. Gabriele será sua guia neste workshop transformador, 
                compartilhando técnicas e insights que <strong>realmente funcionam</strong> para você{" "}
                <strong>despertar seu potencial</strong>.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Workshop Topics Section */}
      <section className="py-20 bg-gradient-secondary">
        <div className="container px-6">
          <div className="text-center mb-16">
            <h2 className="text-lg font-bold text-foreground tracking-wider mb-4">WORKSHOP</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Temas Abordados</h3>
            <p className="text-xl text-muted-foreground">Veja o que você vai aprender em 1 dia de imersão.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto mb-12">
            {[
              "Posicionamento Digital e construção de autoridade",
              "Autoconfiança e mindset empreendedor", 
              "Vendas Estratégicas – como converter com autenticidade",
              "Tráfego Pago e Orgânico para atrair clientes",
              "Conteúdo Criativo e uso de Inteligência Artificial"
            ].map((topic, index) => (
              <Card key={index} className="bg-card/90 backdrop-blur-sm border-primary-foreground/20">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-workshop-gray flex-shrink-0 mt-1" />
                    <p className="font-semibold text-foreground">{topic}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Button 
              onClick={scrollToInvestment}
              size="lg" 
              className="text-xl px-12 py-6 bg-workshop-dark-purple hover:bg-workshop-dark-purple/90 text-workshop-white font-bold rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              Garantir minha vaga
            </Button>
          </div>
        </div>
      </section>

      {/* Investment Section */}
      <section id="investment" className="py-20">
        <div className="container px-6">
          <div className="text-center mb-16">
            <h2 className="text-lg font-bold text-primary tracking-wider mb-4">OFERTA ESPECIAL</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-foreground">Vagas Limitadas</h3>
          </div>

          <div className="max-w-lg mx-auto">
            <Card className="border-primary/30 shadow-2xl bg-gradient-primary">
              <CardContent className="p-8 text-center">
                <div className="mb-6">
                  <p className="text-primary-foreground/80 text-lg line-through mb-2">R$297,00</p>
                  <p className="text-5xl font-bold text-primary-foreground mb-2">R$97,00</p>
                  <p className="text-primary-foreground/90 text-sm">
                    Valor promocional de lançamento para as primeiras participantes (primeiro lote)
                  </p>
                </div>

                <Button 
                  size="lg" 
                  className="w-full text-xl py-6 bg-workshop-dark-purple hover:bg-workshop-dark-purple/90 text-workshop-white font-bold rounded-full shadow-xl transform hover:scale-105 transition-all duration-300 mb-6"
                >
                  Garantir minha vaga
                </Button>

                <ProgressBar label="PRIMEIRO LOTE" value="VAGAS LIMITADAS" className="bg-primary-foreground/10" />
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Schedule Section */}
      <section className="py-20 bg-secondary">
        <div className="container px-6">
          <div className="text-center mb-16">
            <h2 className="text-lg font-bold text-foreground tracking-wider mb-4">CRONOGRAMA</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Evento presencial em São Paulo</h3>
            <p className="text-xl text-muted-foreground">1 dia de imersão transformadora:</p>
          </div>

          <div className="max-w-2xl mx-auto">
            <Card className="bg-card/90 backdrop-blur-sm border-primary-foreground/20">
              <CardContent className="p-8">
                <div className="flex items-center justify-center space-x-6 text-center">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-6 h-6 text-primary" />
                    <span className="font-semibold text-foreground">27/09</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-6 h-6 text-primary" />
                    <span className="font-semibold text-foreground">PRESENCIAL EM SÃO PAULO</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-6 h-6 text-primary" />
                    <span className="font-semibold text-foreground">09:00 às 18:00</span>
                  </div>
                </div>
                <p className="text-center text-muted-foreground mt-4">
                  Inclui intervalo para almoço e networking.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Guarantee Section */}
      <section className="py-20">
        <div className="container px-6">
          <div className="text-center mb-16">
            <h2 className="text-lg font-bold text-primary tracking-wider mb-8">GARANTIA</h2>
          </div>

          <div className="max-w-2xl mx-auto text-center">
            <div className="mb-8">
              <Shield className="w-24 h-24 text-primary mx-auto mb-6" />
              <h3 className="text-3xl font-bold text-foreground mb-4">Garantia de Satisfação</h3>
              <p className="text-lg text-muted-foreground">
                Se ao final do workshop você sentir que não foi o que esperava, devolvemos 100% do seu investimento.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-gradient-primary">
        <div className="container px-6">
          <div className="text-center mb-16">
            <h2 className="text-lg font-bold text-primary-foreground tracking-wider mb-4">INSCREVA-SE AGORA</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-8">
              Não fique de fora dessa experiência transformadora.
            </h3>
            <p className="text-xl text-primary-foreground/90 max-w-4xl mx-auto leading-relaxed mb-12">
              <strong>Garanta sua vaga hoje mesmo</strong> e prepare-se para o <strong>Despertar Digital</strong> que 
              levará você e seu negócio a um novo patamar. Esta é a sua hora – <em>inscreva-se agora</em> e faça parte 
              deste movimento de mulheres que estão conquistando o mundo digital!
            </p>
            
            <Button 
              size="lg" 
              className="text-xl px-12 py-6 bg-workshop-dark-purple hover:bg-workshop-dark-purple/90 text-workshop-white font-bold rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              Garantir minha vaga
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-6">
          <div className="text-center mb-16">
            <h2 className="text-lg font-bold text-primary tracking-wider mb-4">FAQ</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-foreground">Perguntas Frequentes</h3>
          </div>

          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto items-start">
            <div className="text-center">
              <img 
                src={thinkingWoman}
                alt="Mulher pensativa"
                className="w-80 h-80 object-cover rounded-full mx-auto shadow-xl"
              />
            </div>

            <div>
              <Accordion type="single" collapsible className="space-y-4">
                <AccordionItem value="item-1" className="border border-primary/20 rounded-lg px-6">
                  <AccordionTrigger className="text-left font-semibold">
                    Onde será realizado o workshop?
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    O workshop será realizado presencialmente em São Paulo. O local exato será informado por e-mail após a confirmação da inscrição.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2" className="border border-primary/20 rounded-lg px-6">
                  <AccordionTrigger className="text-left font-semibold">
                    Serve para iniciantes?
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Sim! O workshop foi pensado tanto para iniciantes quanto para quem já tem alguma experiência no digital. O conteúdo é adaptado para todos os níveis.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3" className="border border-primary/20 rounded-lg px-6">
                  <AccordionTrigger className="text-left font-semibold">
                    Serve para quem já tem experiência?
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Absolutamente! Mesmo profissionais experientes se beneficiam das estratégias avançadas e insights atualizados que serão compartilhados no workshop.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4" className="border border-primary/20 rounded-lg px-6">
                  <AccordionTrigger className="text-left font-semibold">
                    Haverá certificado?
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Sim, todos os participantes receberão um certificado de participação no Workshop O Despertar Digital.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-foreground">
        <div className="container px-6">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-primary-foreground mb-4">
              WORKSHOP O DESPERTAR DIGITAL
            </h2>
            <p className="text-primary-foreground/70">
              Gabriele Campora © 2025 Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;